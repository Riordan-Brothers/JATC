namespace CCI.SimplSharp.Library.Comm.Priority;
        // class declarations

namespace CCI.SimplSharp.Library.Comm.Common;
        // class declarations

namespace CCI.SimplSharp.Library.Comm.Model;
        // class declarations

namespace CCI.SimplSharp.Library.Comm.Equality;
        // class declarations

